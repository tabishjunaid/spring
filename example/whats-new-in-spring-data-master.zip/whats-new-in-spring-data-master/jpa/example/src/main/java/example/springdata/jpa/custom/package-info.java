/**
 * Package showing a repository interface to use basic query method execution functionality as well as <em>customized</em> repository functionality.
 */
package example.springdata.jpa.custom;

